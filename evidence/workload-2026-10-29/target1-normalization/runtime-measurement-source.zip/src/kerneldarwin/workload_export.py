"""Validate a completed frozen study before copying an installable plan.

This is a reproducibility check, not a cryptographic attestation of local records.
Only the installed authored operation is copied; records cannot supply code.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import random
import tempfile
import statistics
import math
from typing import Any


def _read(path: Path) -> dict[str,Any]:
    if path.stat().st_size>20_000_000:raise ValueError("Evidence file exceeds 20 MB")
    return json.loads(path.read_text())


def _sha(path: Path) -> str:
    if path.stat().st_size>20_000_000:raise ValueError('Evidence file exceeds 20 MB')
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _interval(a: list[float], b: list[float], seed: int = 404) -> dict[str,Any]:
    import math
    if len(a)!=len(b) or not 40<=len(a)<=1000 or any(type(x) not in (int,float) or not math.isfinite(x) or x<=0 for x in [*a,*b]):
        raise ValueError("Need at least 40 finite positive paired costs")
    rng=random.Random(seed);ratios=[]
    for _ in range(4000):
        ids=rng.choices(range(len(a)),k=len(a))
        ratios.append(sum(a[i] for i in ids)/sum(b[i] for i in ids))
    ratios.sort()
    return {"speedup_total_cost":sum(a)/sum(b),"ci95":[ratios[100],ratios[-101]],
            "baseline_total_us":sum(a),"candidate_total_us":sum(b)}


def verify_study(directory: Path) -> dict[str,Any]:
    from .workload import source_identity,environment_identity
    from .study_identity import implementation_identity
    directory=Path(directory)
    protocol=_read(directory/"protocol.json");policy=_read(directory/"policy-frozen.json")
    if policy["evidence"].get("numerical_passed") is not True:
        raise ValueError("Policy has not passed numerical verification")
    if policy["evidence"]["protocol_sha256"]!=_sha(directory/"protocol.json"):
        raise ValueError("Frozen protocol changed")
    if policy["source_sha256"]!=source_identity() or policy["environment"]!=environment_identity():
        raise ValueError("Operation source or runtime changed since study")
    if policy['study_identity']!=implementation_identity() or protocol['study_identity']!=implementation_identity():
        raise ValueError('Application, library baseline or measurement source changed')
    corpus_sha=_sha(directory/'corpus.json')
    if corpus_sha!=protocol['corpus_sha256'] or corpus_sha!=policy['evidence']['corpus_sha256']:
        raise ValueError('Frozen workload corpus changed')
    if not protocol.get('baseline_noise'):raise ValueError('Baseline noise study missing')
    for row in protocol['baseline_noise']:
        low,high=_interval(row['baseline_a_us'],row['baseline_b_us'])['ci95']
        if low<.9 or high>1.1:raise ValueError('Prospective identical-baseline stability gate failed')
    numerical=_read(directory/"numerical-validation.json")
    if numerical.get('study_identity')!=implementation_identity():raise ValueError('Numerical application/baseline/study source changed')
    if numerical.get("source_sha256")!=policy["source_sha256"] or numerical.get("environment")!=policy["environment"] or numerical.get("success") is not True or numerical.get("gpu_executed") is not True or numerical.get("tests_run",0)<6 or any(numerical.get(k)!=0 for k in ("failures","errors","skipped")):
        raise ValueError("Independent current-source GPU numerical validation missing or failed")
    if policy["evidence"].get("numerical_report_sha256")!=_sha(directory/"numerical-validation.json"):
        raise ValueError("Numerical report changed after tuning")
    development=_read(directory/"development.json")
    if development.get("source_sha256")!=policy["source_sha256"] or development.get("protocol_sha256")!=_sha(directory/"protocol.json"):
        raise ValueError("Development source or protocol changed")
    if development.get('study_identity')!=implementation_identity() or policy['evidence'].get('development_sha256')!=_sha(directory/'development.json'):
        raise ValueError('Development implementation or frozen bytes changed')
    if development.get('corpus_sha256')!=corpus_sha:raise ValueError('Development corpus mismatch')
    if not development.get("rows") or any(row.get("numerical_check",{}).get("passed") is not True for row in development["rows"]):
        raise ValueError("Development numerical evidence missing or failed")
    sessions=[]
    methods={'library','eager_library','fast_library','compiled_application','fast_compiled_application','best_fixed','per_shape','dispatcher'}
    baselines=('library','fast_library','compiled_application','fast_compiled_application')
    expected_checks={(task['id'],method) for task in [*protocol['tasks'],protocol['confirmation']['unseen_task']] for method in methods}
    for i in range(3):
        result=_read(directory/f"confirmation-{i}.json")
        if result["session"]!=i or result["seed"]!=protocol["confirmation"]["seeds"][i]:raise ValueError("Wrong independent session identity")
        if result['sequence_order']!=protocol['confirmation']['sequence_orders'][i]:raise ValueError('Wrong untouched sequence order')
        if result["source_sha256"]!=policy["source_sha256"] or result["environment"]!=policy["environment"]:
            raise ValueError("Confirmation source/runtime mismatch")
        if result.get('study_identity')!=implementation_identity():raise ValueError('Confirmation application/baseline/study source mismatch')
        if result.get('corpus_sha256')!=corpus_sha:raise ValueError('Confirmation corpus mismatch')
        if result["protocol_sha256"]!=_sha(directory/"protocol.json") or result["policy_sha256"]!=_sha(directory/"policy-frozen.json"):
            raise ValueError("Confirmation plan/protocol changed")
        if not result["checks"] or any(c.get("scores_passed") is not True for c in result["checks"]):raise ValueError("Application correctness failed")
        if len(result['checks'])!=len(expected_checks) or {(c['task'],c['method']) for c in result['checks']}!=expected_checks:
            raise ValueError('Incomplete application/method numerical checks')
        for key in ('normalization_samples_us','application_samples_us'):
            if set(result[key])!=methods or any(len(v)!=protocol['confirmation']['repeats_per_session'] for v in result[key].values()):
                raise ValueError('Incomplete paired method samples')
        counts=result["fallback_counts"]["dispatcher"]
        if counts["fallback_calls"]<1:raise ValueError("Unseen-input fallback was not exercised")
        sessions.append(result)
    comparisons={}
    for stage,key in (("normalization","normalization_samples_us"),("application","application_samples_us")):
        combined={name:[v for s in sessions for v in s[key][name]] for name in sorted(methods)}
        comparisons[stage]={name:_interval(combined["library"],combined[name]) for name in combined if name!="library"}
        comparisons[stage]["dispatcher_vs_fixed"]=_interval(combined["best_fixed"],combined["dispatcher"])
        comparisons[stage]["dispatcher_vs_fast_library"]=_interval(combined["fast_library"],combined["dispatcher"])
    threshold=protocol["criterion"]["normalization_ci95_lower_speedup"]
    per_session=[{stage:{baseline:_interval(s[key][baseline],s[key]['dispatcher'],s['seed']) for baseline in baselines} for stage,key in (('normalization','normalization_samples_us'),('application','application_samples_us'))} for s in sessions]
    normalization_passed=all(s['normalization'][baseline]['ci95'][0]>threshold for s in per_session for baseline in baselines)
    application_passed=all(s['application'][baseline]['ci95'][0]>protocol['criterion']['application_claim_ci95_lower_speedup'] for s in per_session for baseline in baselines)
    # Independent sessions must each support the application direction. A pooled
    # interval cannot hide one session with a point-estimate regression.
    application_consistent=all(sum(s["application_samples_us"]["library"])>sum(s["application_samples_us"]["dispatcher"]) for s in sessions)
    resource_passed=0<development["search_wall_seconds"]<=protocol["limits"]["development_wall_seconds"] and 0<=development["peak_memory_bytes"]<=protocol["limits"]["memory_bytes"] and max(s["peak_memory_bytes"] for s in sessions)<=protocol["limits"]["memory_bytes"]
    cold=_read(directory/'cold-study.json')
    if cold.get('study_identity')!=implementation_identity() or cold.get('corpus_sha256')!=corpus_sha or cold.get('policy_sha256')!=_sha(directory/'policy-frozen.json'):
        raise ValueError('Cold-start study source/data/policy mismatch')
    if len(cold['rows'])!=3*len(methods) or {(r['repeat'],r['method']) for r in cold['rows']}!={(i,m) for i in range(3) for m in methods}:
        raise ValueError('Incomplete independent cold-start study')
    for row in cold['rows']:
        if row.get('environment')!=policy['environment'] or row.get('study_identity')!=implementation_identity() or row.get('source_sha256')!=source_identity():raise ValueError('Cold-start worker identity mismatch')
        if not all(type(row[k]) in (int,float) and math.isfinite(row[k]) and row[k]>0 for k in ('process_wall_ms','first_application_sequence_ms','policy_setup_ms')):
            raise ValueError('Invalid cold-start costs')
    resource_passed=resource_passed and cold['wall_seconds']<=180 and max(r['peak_memory_bytes'] for r in cold['rows'])<=protocol['limits']['memory_bytes']
    cold_summary={m:{'median_process_wall_ms':statistics.median(r['process_wall_ms'] for r in cold['rows'] if r['method']==m),
        'median_first_sequence_ms':statistics.median(r['first_application_sequence_ms'] for r in cold['rows'] if r['method']==m)} for m in methods}
    warm_baseline=min(sum(s['application_samples_us'][m][i] for s in sessions for i in range(len(s['application_samples_us'][m]))) for m in baselines)
    warm_candidate=sum(sum(s['application_samples_us']['dispatcher']) for s in sessions)
    savings=(warm_baseline-warm_candidate)/sum(len(s['application_samples_us']['dispatcher']) for s in sessions)
    cold_extra=max(0,cold_summary['dispatcher']['median_process_wall_ms']-min(cold_summary[m]['median_process_wall_ms'] for m in baselines))*1000
    break_even=math.ceil((development['search_wall_seconds']*1e6+cold_extra)/savings) if savings>0 else None
    return {"schema":1,"numerical_passed":True,"normalization_passed":normalization_passed,"application_passed":application_passed and application_consistent,
        "confirmation_passed":normalization_passed and application_passed and application_consistent and resource_passed,
        "comparisons":comparisons,"per_session":per_session,"resource_passed":resource_passed,
        'cold_start':cold_summary,'amortization_break_even_application_sequences':break_even,
        "source_sha256":source_identity(),"environment":policy["environment"],
        "evidence_sha256":{p.name:_sha(p) for p in [directory/"protocol.json",directory/"policy-frozen.json",directory/"development.json",directory/"numerical-validation.json",directory/'corpus.json',directory/'cold-study.json',*[directory/f"confirmation-{i}.json" for i in range(3)]]},
        "limitations":["Host wall timings include dispatch/allocation/materialization and observed background contention.",
            "Pooled paired bootstrap is descriptive; all independent session directions and per-session normalization intervals are additionally gated.",
            "No learned selector, cross-device speedup or adoption claim."]}


def export_artifact(study: Path, output: Path) -> dict[str,Any]:
    from .workload import _LOADED_SOURCE
    verified=verify_study(study)
    if verified["confirmation_passed"] is not True:raise ValueError("Frozen confirmation failed; export refused. Keep the null result.")
    if output.exists():raise FileExistsError("Choose a new artifact directory")
    policy=_read(study/"policy-frozen.json")
    if not policy["rules"]:raise ValueError("No independently confirmed optimized dispatch rules")
    if sum(len(source) for _,source in _LOADED_SOURCE)>12_000:raise ValueError("Source-size budget exceeded")
    policy["evidence"]={**policy["evidence"],"confirmation_passed":True,"verification":verified["evidence_sha256"]}
    from .workload import Normalizer
    output.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='kd-export-',dir=output.parent) as directory:
        staging=Path(directory)/'artifact';staging.mkdir()
        for name,source in _LOADED_SOURCE:(staging/name).write_bytes(source)
        (staging/"manifest.json").write_text(json.dumps(policy,indent=2)+"\n")
        (staging/"verification.json").write_text(json.dumps(verified,indent=2)+"\n")
        if Normalizer(staging).status!='installed':raise ValueError('Exported plan failed its own runtime compatibility guards')
        if output.exists():raise FileExistsError('Output appeared while preparing artifact')
        staging.rename(output)
    return {"artifact":str(output),"source_sha256":verified["source_sha256"],"confirmation_passed":True,"bytes":sum(p.stat().st_size for p in output.iterdir())}
