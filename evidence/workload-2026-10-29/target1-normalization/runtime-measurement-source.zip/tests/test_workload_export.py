"""Synthetic CPU fixtures test promotion guards; never hardware evidence."""
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from kerneldarwin.workload_export import export_artifact,verify_study
from kerneldarwin.workload import source_identity,_LOADED_SOURCE
from kerneldarwin.study_identity import implementation_identity


def write(path,value):path.write_text(json.dumps(value))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def fixture(root):
    environment={'unit_fixture':'synthetic; no GPU execution'}
    write(root/'corpus.json',{'chunks':['synthetic unit test corpus']})
    protocol={'corpus_sha256':sha(root/'corpus.json'),'study_identity':implementation_identity(),'baseline_noise':[{'baseline_a_us':[10.]*40,'baseline_b_us':[10.]*40}],
              'tasks':[{'id':'known'}],'confirmation':{'seeds':[71,82,93],'unseen_task':{'id':'unseen'},'sequence_orders':[[0,1],[1,0],[0,1]],'repeats_per_session':40},'criterion':{'normalization_ci95_lower_speedup':1.1,'application_claim_ci95_lower_speedup':1.03},
              'limits':{'development_wall_seconds':900,'memory_bytes':2*1024**3}}
    write(root/'protocol.json',protocol)
    numerical={'study_identity':implementation_identity(),'source_sha256':source_identity(),'environment':environment,'success':True,'gpu_executed':True,'tests_run':12,'failures':0,'errors':0,'skipped':0,'fixture':True}
    write(root/'numerical-validation.json',numerical)
    policy={'study_identity':implementation_identity(),'schema':1,'operation':'stable_l2_rows_v1','epsilon':1e-12,'sources':{name:hashlib.sha256(source).hexdigest() for name,source in _LOADED_SOURCE},'source_sha256':source_identity(),'environment':environment,'rules':[{'shape':[1,33],'candidate':'simd','dtype':'float32','layout':'any_mlx_strides'}],
            'evidence':{'corpus_sha256':sha(root/'corpus.json'),'numerical_passed':True,'confirmation_passed':False,'protocol_sha256':sha(root/'protocol.json'),'numerical_report_sha256':sha(root/'numerical-validation.json')}}
    write(root/'policy-frozen.json',policy)
    development={'corpus_sha256':sha(root/'corpus.json'),'study_identity':implementation_identity(),'source_sha256':source_identity(),'protocol_sha256':sha(root/'protocol.json'),'rows':[{'numerical_check':{'passed':True}}],'search_wall_seconds':1,'peak_memory_bytes':1024}
    write(root/'development.json',development)
    policy['evidence']['development_sha256']=sha(root/'development.json');write(root/'policy-frozen.json',policy)
    samples={name:[value+(i%3)*.001 for i in range(40)] for name,value in (('library',10),('eager_library',12),('fast_library',9),('compiled_application',9),('fast_compiled_application',8),('best_fixed',2),('per_shape',1.1),('dispatcher',1))}
    for i in range(3):
        record={'corpus_sha256':sha(root/'corpus.json'),'study_identity':implementation_identity(),'session':i,'seed':protocol['confirmation']['seeds'][i],'sequence_order':protocol['confirmation']['sequence_orders'][i],'source_sha256':source_identity(),'environment':environment,
                'protocol_sha256':sha(root/'protocol.json'),'policy_sha256':sha(root/'policy-frozen.json'),
                'checks':[{'task':task,'method':method,'scores_passed':True} for task in ('known','unseen') for method in samples], 'fallback_counts':{'dispatcher':{'fallback_calls':1}},
                'normalization_samples_us':samples,'application_samples_us':samples,'peak_memory_bytes':2048}
        write(root/f'confirmation-{i}.json',record)
    cold={'source_sha256':source_identity(),'study_identity':implementation_identity(),'corpus_sha256':sha(root/'corpus.json'),'policy_sha256':sha(root/'policy-frozen.json'),'wall_seconds':1,
          'rows':[{'repeat':i,'method':method,'source_sha256':source_identity(),'study_identity':implementation_identity(),'environment':environment,'process_wall_ms':100.,'first_application_sequence_ms':10.,'policy_setup_ms':1.,'peak_memory_bytes':2048} for i in range(3) for method in samples]}
    write(root/'cold-study.json',cold)
    return environment


class ExportTests(unittest.TestCase):
    def test_one_independent_fast_library_loss_cannot_hide_in_pooled_wins(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);environment=fixture(root)
            p=json.loads((root/'confirmation-2.json').read_text())
            for stage in ('normalization_samples_us','application_samples_us'):p[stage]['fast_library']=[.5]*40
            write(root/'confirmation-2.json',p)
            with patch('kerneldarwin.workload.environment_identity',return_value=environment):
                self.assertFalse(verify_study(root)['confirmation_passed'])
                with self.assertRaises(ValueError):export_artifact(root,root/'artifact')
            self.assertFalse((root/'artifact').exists())
    def test_complete_synthetic_study_can_export_and_missing_session_refuses(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);environment=fixture(root)
            with patch('kerneldarwin.workload.environment_identity',return_value=environment):
                result=export_artifact(root,root/'artifact')
                self.assertTrue(result['confirmation_passed'])
                self.assertTrue(json.loads((root/'artifact/manifest.json').read_text())['evidence']['confirmation_passed'])
                (root/'confirmation-2.json').unlink()
                with self.assertRaises(FileNotFoundError):verify_study(root)

    def test_false_numerical_policy_and_report_tampering_refuse(self):
        for mutation in ('false_policy','changed_report','failed_report'):
            with self.subTest(mutation=mutation),tempfile.TemporaryDirectory() as directory:
                root=Path(directory);environment=fixture(root)
                if mutation=='false_policy':
                    p=json.loads((root/'policy-frozen.json').read_text());p['evidence']['numerical_passed']=False;write(root/'policy-frozen.json',p)
                else:
                    p=json.loads((root/'numerical-validation.json').read_text());p['success']=False if mutation=='failed_report' else True;p['changed']=True;write(root/'numerical-validation.json',p)
                with patch('kerneldarwin.workload.environment_identity',return_value=environment),self.assertRaises(ValueError):verify_study(root)

    def test_stale_empty_failed_or_over_budget_development_cannot_promote(self):
        for mutation in ('source','protocol','empty','numerical','memory','corpus'):
            with self.subTest(mutation=mutation),tempfile.TemporaryDirectory() as directory:
                root=Path(directory);environment=fixture(root)
                p=json.loads((root/'development.json').read_text())
                if mutation=='source':p['source_sha256']='stale'
                elif mutation=='protocol':p['protocol_sha256']='stale'
                elif mutation=='empty':p['rows']=[]
                elif mutation=='numerical':p['rows'][0]['numerical_check']['passed']=False
                elif mutation=='corpus':write(root/'corpus.json',{'chunks':['changed corpus']})
                else:p['peak_memory_bytes']=3*1024**3
                write(root/'development.json',p)
                with patch('kerneldarwin.workload.environment_identity',return_value=environment):
                    with self.assertRaises(ValueError):export_artifact(root,root/'artifact')
                self.assertFalse((root/'artifact').exists())


if __name__=='__main__':unittest.main()
